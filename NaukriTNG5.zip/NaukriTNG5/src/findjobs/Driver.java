package findjobs;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.BeforeTest;
import java.io.File;
import java.time.LocalDateTime;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterTest;

@Listeners(tnglisteners.TestNGListeners.class)
public class Driver extends GlobalFunctions
{
  
  @DataProvider
  public Object [][] JobLocation ()
  {
	int dctsize = Dictionary.values().size();
	
	Object[][] data = new Object [dctsize][2];
	int i=0;
	for (Object obj : Dictionary.values())
	{
		String[] Words = obj.toString().split("\\+");
		String SearchJobName = Words[0];
		String SearchLocation = Words[1];
		data[i][0] = SearchJobName;
		data[i][1] = SearchLocation;
		i++;
	}
	  return data;
  }
  
  @DataProvider
  public Object [][] MailInfo ()
  {
	int dctsize = MailDct.values().size();
	
	Object[][] data = new Object [dctsize][3];
	int i=0;
	for (Object obj : MailDct.values())
	{
		String[] Words = obj.toString().split("\\+");
		data[i][0] = Words[0];
		data[i][1] = Words[1];
		data[i][2] = Words[2];
		i++;
	}
	  return data;
  }
	
  @Test(priority=1)
  public void ReadJobsFromExcel() throws Exception
  {
	  MicrosoftLibrary.ReadEntries();
  }
  
  @Test(priority=2,dataProvider="JobLocation")
  public void SearchTheJobs(String SearchJobName,String SearchLocation) throws Exception 
  {
	LoggerLibrary.PostExecDetails("Execution Starts " + LocalDateTime.now().toString(),micInfo,false);
	 
	//Set Up Selenium Driver
	DriverSettings ("Chrome");
			
	//Search Jobs
	NaukriDotCom.SearchJobs(SearchJobName,SearchLocation);
	MicrosoftLibrary.WriteToExcel (SearchJobName+" - "+SearchLocation);	
	JobStorage.clear();
  }
  
  @Test(priority=3)
  public void ExportJobsToExcel() throws Exception
  {
	 MicrosoftLibrary.ExportToExcel();
	 MicrosoftLibrary.FormatSummaryReport();
	 Dictionary.clear();
  }
  
  @Test(priority=4)
  public void ReadMailData() throws Exception
  {
	  MicrosoftLibrary.ReadSendMail();
	  MicrosoftLibrary.LoadConfigFile();
  }
  
  @Test(priority=5,dataProvider="MailInfo")
  public void MailJobReport(String UserName,String Recepient,String Subject) throws Exception
  {
	  //Set Up Selenium Driver
	  DriverSettings ("Chrome");
	  Rediffmail.SendMail(UserName,Recepient,Subject);
  }
  
  @Test(priority=6)
  public void SaveReport() throws Exception
  {
	  LoggerLibrary.PostExecDetails("Saving JobReportSummary by local date format",micInfo,false);
	  File srcfile = new File(JobSummaryReportPath);
	  File dstfile = new File(StoredJobSummaryReportPath);
	  FileHandler.copy(srcfile, dstfile);
	  LoggerLibrary.PostExecDetails("Saved To "+StoredJobSummaryReportPath,micInfo,false);
	  srcfile.delete();
  }
  
  @BeforeTest
  public void beforeTest() throws Exception 
  {
	  CreateFolder(AutomationFolder);
	  CreateFolder(TestLogFolder);
	  CreateFolder(TestReportFolder);
	  CreateFolder(TestResultFolder);
	  CreateFolder(TestSnapFolder);
	  CreateFolder(TestSnapCaseFolder);
	  LoggerLibrary.PostExecDetails("Before Test : All Folders Created And Logger",micInfo,false);
  }

  @AfterTest
  public void afterTest() throws Exception 
  {
	  MailDct.clear();
	  ConfigDct.clear();
	  LoggerLibrary.PostExecDetails("After Test : Driver Quit and Log Manager ShutDown",micInfo,false);
	  LoggerLibrary.PostExecDetails("Execution Ends " + LocalDateTime.now().toString(),micInfo,false);
	  ExitTest();
  }
  
}
