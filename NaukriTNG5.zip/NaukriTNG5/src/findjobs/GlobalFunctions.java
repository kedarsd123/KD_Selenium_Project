package findjobs;

import java.io.File;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class GlobalFunctions implements GlobalVariables
{
	//Driver Settings
	public static WebDriver d;
	public static WebDriverWait w;
	
	//HTML Settings
	public static ExtentHtmlReporter htmlreporter;
	public static ExtentReports htmlreport;
	public static ExtentTest htmllogger;
	
	public static void DriverSettings (String S) throws Exception
	{
		if (S.toUpperCase().equalsIgnoreCase("CHROME"))
		{
			System.setProperty(ChromeDriver,ChromeDriverAddress);
			ChromeOptions ch = new ChromeOptions();
			ch.addArguments("--disable-notifications");
			d = new ChromeDriver (ch);
			w = new WebDriverWait(d,SHORTWAIT);
			d.manage().timeouts().implicitlyWait(SHORTWAIT, TimeUnit.SECONDS);
			d.manage().timeouts().pageLoadTimeout(SHORTWAIT, TimeUnit.SECONDS);
			LoggerLibrary.PostExecDetails("Driver Settings Done For "+ S,micInfo,false);
		}
		else
		{
			LoggerLibrary.PostExecDetails("Case Not Handled For Browser "+S,micInfo,false);
			ExitTest();
		}
	}
	
	public static void CreateFolder(String S)
	{
		File folder = new File (S);
		folder.mkdir();
		LoggerLibrary.PrintLog(S);
	}
	
	public static void ExitTest() throws Exception
	{
		LoggerLibrary.PostExecDetails("System Exit",micInfo,false);
		System.exit(0);
	}
	
	public static void WaitUntilVisibleOnWeb(By Locator)
	{
		w.until(ExpectedConditions.visibilityOfElementLocated(Locator));
	}
	
	public static void WebPageActions (String Option)
	{
		if (Option=="Maximise")
			d.manage().window().maximize();
		else if (Option=="Close")
			d.close();
		else if (Option=="Quit")
			d.quit();
	}
	
	public static void Paste (By Locator,String S) throws Exception
	{
		try
		{
			w.until(ExpectedConditions.visibilityOfElementLocated(Locator));
			d.findElement(Locator).clear();
			d.findElement(Locator).click();
			d.findElement(Locator).sendKeys(S);
			d.findElement(Locator).sendKeys(Keys.TAB);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			LoggerLibrary.PostExecDetails(e.toString(),micFail,false);
			d.quit();
			ExitTest();
		}
		
	}
	
	public static void Click (By Locator) throws Exception
	{
		try
		{
			w.until(ExpectedConditions.visibilityOfElementLocated(Locator));
			d.findElement(Locator).click();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			LoggerLibrary.PostExecDetails("Unable To Click Element By Locator : "+ Locator,micFail,false);
			LoggerLibrary.PostExecDetails(e.toString(),micFail,false);
			d.quit();
			ExitTest();
		}
	}
	
	public static void HtmlSettings()
	{
		htmlreporter = new ExtentHtmlReporter(HTMLResultPath);
		htmlreporter.config().setEncoding("utf-8");
		htmlreporter.config().setDocumentTitle("NaukriDotCom HTML Report");
		htmlreporter.config().setReportName("NaukriDotCom TestNG Runs");
		htmlreporter.config().setTheme(Theme.STANDARD);
		htmlreport = new ExtentReports();
		htmlreport.setSystemInfo("Browser", "Chrome");
		htmlreport.setSystemInfo("Automation","Selenium");
		htmlreport.setSystemInfo("Technology","TestNG");
		htmlreport.setSystemInfo("Report Type","Excel + HTML");
		htmlreport.attachReporter(htmlreporter);
	}
	
}
