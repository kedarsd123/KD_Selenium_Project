package findjobs;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public interface GlobalVariables 
{
	//Driver Settings
	String ChromeDriver = "webdriver.chrome.driver";
	String ChromeDriverAddress = "E:\\CommonSetup\\chromedriver_win32\\chromedriver.exe";
	
	//Set Up Dynamic Waits Time In Seconds
	int SHORTWAIT = 300;
	
	//Set Up Dictionary
	HashMap<String, String> ConfigDct = new HashMap<String, String>();
	HashMap<Integer, String> MailDct = new HashMap<Integer, String>();
	HashMap<Integer, String> Dictionary = new HashMap<Integer, String>();
	HashMap<Integer, Object[]> JobStorage = new HashMap<Integer, Object[]>();
	
	//Excel Result Logger Modifier
	String formatDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")).replaceAll(":", "_");
	
	//Directories
	String ProjectFolder = System.getProperty("user.dir");
	String DataScriptFolder = ProjectFolder.concat("\\DataScript");
	String AutomationFolder = ProjectFolder.concat("\\Automation");
	String TestLogFolder = AutomationFolder.concat("\\TestLog");
	String TestReportFolder = AutomationFolder.concat("\\TestReport");
	String TestResultFolder = AutomationFolder.concat("\\TestResult");
	String TestSnapFolder = AutomationFolder.concat("\\TestScreenshot");
	String TestSnapCaseFolder = TestSnapFolder.concat("\\").concat(formatDateTime);
	String TestHTMLReportFolder = AutomationFolder.concat("\\TestHTMLReport");
	
	//Excel Paths
	String ExcelPath = DataScriptFolder.concat("\\FindJobs.xlsx");
	String SampleLogger = DataScriptFolder.concat("\\Logger.xlsx");
	String ResultLogger = TestResultFolder.concat("\\Logger_").concat(formatDateTime).concat(".xlsx");
	String JobSummaryReportPath = TestReportFolder.concat("\\JobSummaryReport.xlsx");
	String StoredJobSummaryReportPath = TestReportFolder.concat("\\JobSummaryReport_").concat(formatDateTime).concat(".xlsx");
	
	//HTML Result Path
	String HTMLResultPath = TestHTMLReportFolder.concat("\\HTMLLogger_").concat(formatDateTime).concat(".html");
	
	//Mail Config VBS Path
	String MailConfigPath = DataScriptFolder.concat("\\MailConfig.vbs");
	
	//Global XSSF Workbook
	XSSFWorkbook rsworkbook = new XSSFWorkbook();
	
	//Common URLs
	String NaukriURL = "https://www.naukri.com/";
	String RediffURL = "https://www.rediff.com/";
	
	//AutoIT Script
	String AutoITexe = DataScriptFolder.concat("\\AutoitScript\\JobSummaryReport.exe");
	
	//Excel Header Details For FindJobs.xlsx Entries Sheet
	int RunCol = 1,JobTypeCol = 2, LocationCol = 3;
	
	//Excel Header Details For FindJobs.xlsx SendMail Sheet
	int UserNameCol = 1,RecepientCol = 2,SubjectCol = 3;
	
	//Logger Parameters
	String micPass = "Passed", micFail = "Failed", micWarning = "Warning", micInfo = "Info";
	
}
