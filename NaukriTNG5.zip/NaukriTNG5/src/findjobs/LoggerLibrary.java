package findjobs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;
import org.testng.Reporter;

import com.aventstack.extentreports.Status;

public class LoggerLibrary extends Driver
{
	//For Pasting Screenshots in Excel
	public static int PicPasteRow = 0;
	//Logger Only One Time Creation
	public static int LogCreationTime = 0;
	//Snapshot Naming and creation
	public static int cssnum=0;
	public static String SnapShotName;
	//log4j details
	public static Logger log = Logger.getLogger(LoggerLibrary.class.getName());
	//Excel Writing Rows
	public static int ExcelStartRow = 1;
	
	public static void CreateLogger() throws Exception
	{
		File srcfile = new File(SampleLogger);
		File dstfile = new File(ResultLogger);
		FileHandler.copy(srcfile, dstfile);
	}
	
	public static void Print(String S)
	{
		System.out.println(S);
	}
	
	public static void PrintLog (String S)
	{
		log.info(S);
		Reporter.log(S, true);
	}
	
	public static void CaptureScreenShot()
	{
		cssnum++;
		SnapShotName = "SnapShot_".concat(String.valueOf(cssnum).concat(".png"));
		File SrcFile = ((TakesScreenshot)d).getScreenshotAs(OutputType.FILE);
		File DstFile = new File (TestSnapCaseFolder.concat("\\").concat(SnapShotName));
		try 
		{
			FileHandler.copy(SrcFile,DstFile);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			PrintLog(e.toString());
		}
	}
	
	public static void PostResult(String S,String strStatus,Boolean Snap) throws Exception
	{
		File ResLogger = new File(ResultLogger);
		FileInputStream InputStream = new FileInputStream (ResLogger);
		Workbook LoggerExcel = new XSSFWorkbook(InputStream);
		if (Snap.equals(true))
		{
			CaptureScreenShot();
			Sheet Screenshots = LoggerExcel.getSheet("Screenshots");
			InputStream SnapStream = new FileInputStream(TestSnapCaseFolder.concat("\\").concat(SnapShotName));
			byte[] bytes = IOUtils.toByteArray(SnapStream);
			//Adds a picture to the workbook
			int pictureIdx = LoggerExcel.addPicture(bytes, LoggerExcel.PICTURE_TYPE_PNG);
			//close the input stream
			SnapStream.close();
			//Returns an object that handles instantiating concrete classes
			CreationHelper helper = LoggerExcel.getCreationHelper();
			//Creates the top-level drawing patriarch.
			Drawing drawing = Screenshots.createDrawingPatriarch();
			//Create an anchor that is attached to the worksheet
			ClientAnchor anchor = helper.createClientAnchor();
			anchor.setCol1(1);
			anchor.setRow1(PicPasteRow);
			//Creates a picture
			Picture pict = drawing.createPicture(anchor, pictureIdx);
			//Reset the image to the original size
			pict.resize();
			
			PicPasteRow = PicPasteRow + 46;
		}
		
		Sheet Details = LoggerExcel.getSheet("Details");
		Row RowControl = Details.createRow(ExcelStartRow);
		RowControl.createCell(0).setCellValue(String.valueOf(ExcelStartRow));
		RowControl.createCell(1).setCellValue(S);
		RowControl.createCell(2).setCellValue(strStatus);
		if (Snap.equals(true))
		{
			String temp = "HYPERLINK(\""+ TestSnapCaseFolder.concat("\\").concat(SnapShotName) + "\", \"Snap\")";
			RowControl.createCell(3).setCellFormula(temp);
		}
		//AutoFit Columns
		int lcn = Details.getRow(0).getLastCellNum();
		for (int i=0; i<lcn; i++)
		{
			Details.autoSizeColumn(i);
		}
		FileOutputStream fileOut = new FileOutputStream(ResultLogger);
		LoggerExcel.write(fileOut);
		LoggerExcel.close();
		ExcelStartRow++;
	}
	
	public static void PostExecDetails(String S,String strStatus,Boolean Snap) throws Exception
	{
		if (LogCreationTime==0)
		{
			CreateLogger();
			GlobalFunctions.HtmlSettings();
		}
		
		PrintLog (S);
		PostResult(S,strStatus,Snap);
		LogHTMLPage(S,strStatus,Snap);
		
		if (S.equalsIgnoreCase("System Exit"))
		{
			FormatExcelLogger();
		}
		
		LogCreationTime++;
	}
	
	public static void LogHTMLPage (String S,String strStatus,Boolean Snap) throws Exception
	{
		htmllogger = htmlreport.createTest(S);
		
		if (strStatus.equalsIgnoreCase(micPass))
			htmllogger.log(Status.PASS,"Passed");
		else if (strStatus.equalsIgnoreCase(micFail))
			htmllogger.log(Status.FAIL,"Failed");
		else if (strStatus.equalsIgnoreCase(micWarning))
			htmllogger.log(Status.WARNING,"Warning");
		else if (strStatus.equalsIgnoreCase(micInfo))
			htmllogger.log(Status.INFO,"Information");
		
		if (Snap.equals(true))
		{
			htmllogger.addScreenCaptureFromPath(TestSnapCaseFolder.concat("\\").concat(SnapShotName));
		}
		
		if (S.equalsIgnoreCase("System Exit"))
		{
			htmlreport.flush();
		}
	}
	
	public static void FormatExcelLogger() throws Exception
	{
		HashMap<String, Object> property1 = new HashMap<String, Object>();
		
		//Set Border Around Cell
		property1.put(CellUtil.BORDER_TOP, BorderStyle.THIN);
		property1.put(CellUtil.BORDER_BOTTOM, BorderStyle.THIN);
		property1.put(CellUtil.BORDER_LEFT, BorderStyle.THIN);
		property1.put(CellUtil.BORDER_RIGHT, BorderStyle.THIN);
		
		File file = new File(ResultLogger);
		FileInputStream InputStream = new FileInputStream (file);
		Workbook JsrWb = new XSSFWorkbook(InputStream);
		
		Sheet sh = JsrWb.getSheet("Details");
		int FirstRowNum = sh.getFirstRowNum();
		int LastRowNum = sh.getLastRowNum();
		int RowCount = LastRowNum - FirstRowNum + 1;
		
		//j for number of rows
		for (int j=1;j<RowCount;j++)
		{
			Row R1 = sh.getRow(j);
			int CellCount = R1.getLastCellNum();
			
			for (int k=0;k<CellCount;k++)
			{
				Cell c1 = R1.getCell(k);
				CellUtil.setCellStyleProperties(c1, property1);
			}
		}
		
		FileOutputStream fileOut = new FileOutputStream(ResultLogger);
		JsrWb.write(fileOut);
		JsrWb.close();
	}

}

