package findjobs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

public class MicrosoftLibrary extends Driver
{
	public static void ReadEntries() throws Exception
	{
		File file = new File(ExcelPath);
		FileInputStream InputStream;
		try 
		{
			InputStream = new FileInputStream (file);
			Workbook FindJobs = new XSSFWorkbook(InputStream);
			Sheet Entries = FindJobs.getSheet("Entries");
			int FirstRowNum = Entries.getFirstRowNum();
			int LastRowNum = Entries.getLastRowNum();
			int RowCount = LastRowNum - FirstRowNum + 1;
			for (int i=1; i<RowCount; i++)
			{
				Row RowControl = Entries.getRow(i);
				if (RowControl.getCell(RunCol).getStringCellValue().equalsIgnoreCase("Yes"))
				{
					String JobName = RowControl.getCell(JobTypeCol).getStringCellValue();
					String JobLocation = RowControl.getCell(LocationCol).getStringCellValue();
					Dictionary.put(i, JobName + "+" + JobLocation);
				}
			}
			FindJobs.close();
			LoggerLibrary.PostExecDetails("Input Excel Read Successfully",micInfo,false);
		} 
		catch (Exception e) 
		{
			LoggerLibrary.PostExecDetails("Couldnot Read Job Entries",micFail,false);
			LoggerLibrary.PostExecDetails("Error "+e.toString(),micFail,false);
			Assert.assertTrue(false);
		}
	}
	
	public static void ReadSendMail() throws Exception //throws Exception
	{
		File file = new File(ExcelPath);
		FileInputStream InputStream;
		try 
		{
			InputStream = new FileInputStream (file);
			Workbook FindJobs = new XSSFWorkbook(InputStream);
			Sheet SendMail = FindJobs.getSheet("SendMail");	
			
			int FirstRowNum = SendMail.getFirstRowNum();
			int LastRowNum = SendMail.getLastRowNum();
			int RowCount = LastRowNum - FirstRowNum + 1;
			for (int i=1; i<RowCount; i++)
			{
				Row RowControl = SendMail.getRow(i);
				String UserName = RowControl.getCell(UserNameCol).getStringCellValue();
				String Recepient = RowControl.getCell(RecepientCol).getStringCellValue();
				String Subject = RowControl.getCell(SubjectCol).getStringCellValue();
				MailDct.put(i, UserName+"+"+Recepient+"+"+Subject);
			}
			
			FindJobs.close();
			LoggerLibrary.PostExecDetails("Input Excel Read Successfully",micInfo,false);
		} 
		catch (Exception e) 
		{
			LoggerLibrary.PostExecDetails("CouldNot Read Mail Data",micFail,false);
			LoggerLibrary.PostExecDetails("Error "+e.toString(),micFail,false);
			Assert.assertTrue(false);
		}
	}
	
	public static void WriteToExcel (String WSName) throws Exception
	{
		XSSFSheet spreadsheet = rsworkbook.createSheet(WSName);
		XSSFRow row;
		
		Set <Integer> AllKeyIds = JobStorage.keySet();
		int RowID = 0;
		
		for (Integer key : AllKeyIds)
		{
			row = spreadsheet.createRow(RowID++);
			Object [] objArr = JobStorage.get(key);
			int CellID = 0;
			for (Object obj : objArr)
			{
				Cell cell = row.createCell(CellID++);
				cell.setCellValue(obj.toString());
			}
		}
		
		//AutoFit Columns
		int lcn = spreadsheet.getRow(0).getLastCellNum();
		for (int i=0; i<lcn; i++)
		{
			spreadsheet.autoSizeColumn(i);
		}
		LoggerLibrary.PostExecDetails("Jobs Are Written To Excel Workbook "+WSName,micInfo,false);
	}
	
	public static void ExportToExcel() throws Exception
	{
		File tempfile = new File(JobSummaryReportPath);
		FileOutputStream out;
		try 
		{
			out = new FileOutputStream(tempfile);
			rsworkbook.write(out);
			out.close();
			rsworkbook.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			LoggerLibrary.PostExecDetails("CouldNot Export Data To Excel",micFail,false);
			LoggerLibrary.PostExecDetails("Error "+e.toString(),micFail,false);
		}
		LoggerLibrary.PostExecDetails("Job Summary Is Exported To Excel",micInfo,false);
	}
	
	public static void LoadConfigFile()
	{
		String strLine = "";
		List<String> list = new ArrayList<String>();

		BufferedReader br;
		try 
		{
			br = new BufferedReader(new FileReader(MailConfigPath));
			strLine = br.readLine();
	        while (strLine != null)
	        {
	        	System.out.println(strLine);
	            list.add(strLine);
	            strLine = br.readLine();
	        }
	        br.close();
	        
	        int lstsize = list.size();
	        
	        for (int i=0;i<lstsize;i++)
	        {
	        	String[] words = list.get(i).split("=");
	        	ConfigDct.put(words[0].trim().toString(), words[1].trim().toString());
	        }
	        LoggerLibrary.PostExecDetails("Config Mail VBS File Read Successfully",micInfo,false);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public static void FormatSummaryReport() throws Exception
	{
		HashMap<String, Object> property1 = new HashMap<String, Object>();
		
		//Set Border Around Cell
		property1.put(CellUtil.BORDER_TOP, BorderStyle.THIN);
		property1.put(CellUtil.BORDER_BOTTOM, BorderStyle.THIN);
		property1.put(CellUtil.BORDER_LEFT, BorderStyle.THIN);
		property1.put(CellUtil.BORDER_RIGHT, BorderStyle.THIN);
		
		File file = new File(JobSummaryReportPath);
		FileInputStream InputStream = new FileInputStream (file);
		Workbook JsrWb = new XSSFWorkbook(InputStream);
		
		int wscount = JsrWb.getNumberOfSheets();
		
		//i for number of worksheets
		for (int i=0;i<wscount;i++)
		{
			Sheet sh = JsrWb.getSheetAt(i);
			int FirstRowNum = sh.getFirstRowNum();
			int LastRowNum = sh.getLastRowNum();
			int RowCount = LastRowNum - FirstRowNum + 1;
			
			//j for number of rows
			for (int j=0;j<RowCount;j++)
			{
				Row R1 = sh.getRow(j);
				int CellCount = R1.getLastCellNum();
				
				for (int k=0;k<CellCount;k++)
				{
					Cell c1 = R1.getCell(k);
					CellUtil.setCellStyleProperties(c1, property1);
				}
			}
			
		}
		
		FileOutputStream fileOut = new FileOutputStream(JobSummaryReportPath);
		JsrWb.write(fileOut);
		JsrWb.close();
		
	}

}
