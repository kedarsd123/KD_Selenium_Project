package findjobs;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

public class NaukriDotCom extends Driver
{
	//Object Properties
	public static WebElement Element = null;
	static By PopUp = By.xpath("//div[@id='geoLocPopUp']");
	static By LaterBtn = By.xpath("//span[@id='block']");
	static By Skills = By.xpath("//input[@name='keyword']");
	static By Locations = By.xpath("//input[@name='location']");
	static By SearchBtn = By.xpath("//div[@class='search-btn']");
	static By ListOfJobs = By.xpath("//article[@class='jobTuple bgWhite br4 mb-8']");
	static By JobTitle = By.cssSelector("a[class='title fw500 ellipsis']");
	static By CompanyName = By.cssSelector("a[class='subTitle ellipsis fleft']");
	static By ExperienceReq = By.cssSelector("li[class='fleft grey-text br2 placeHolderLi experience']");
	static By Salary = By.cssSelector("li[class='fleft grey-text br2 placeHolderLi salary']");
	static By Location = By.cssSelector("li[class='fleft grey-text br2 placeHolderLi location']");
	static By Expectation = By.cssSelector("div[class='job-description fs12 grey-text']");
	static By SkillDescription = By.cssSelector("ul[class='tags has-description']");
	static By UnitSkill = By.cssSelector("li[class='fleft fs12 grey-text lh16 dot']");
	
	public static WebElement PopUp ()
	{
		NaukriDotCom.WaitUntilVisibleOnWeb(PopUp);
		Element = d.findElement(PopUp);
		return Element;
	}
	
	public static WebElement LaterBtn (WebElement E)
	{
		Element = E.findElement(LaterBtn);
		return Element;
	}
	
	public static WebElement Skills ()
	{
		Element = d.findElement(Skills);
		return Element;
	}
	
	public static WebElement Locations()
	{
		Element = d.findElement(Locations);
		return Element;
	}
	
	public static WebElement SearchBtn()
	{
		Element = d.findElement(SearchBtn);
		return Element;
	}
	
	public static void KillExcessWindows ()
	{
		String ParentWindow = d.getWindowHandle();
		Set <String> AllWindows = d.getWindowHandles();
		Iterator <String> I1 = AllWindows.iterator();
		
		while (I1.hasNext())
		{
			String ExtraWindow = I1.next();
			if (!ParentWindow.equals(ExtraWindow))
			{
				d.switchTo().window(ExtraWindow).close();
			}
		}
		d.switchTo().window(ParentWindow);
	}
	
	public static void SearchJobs(String SearchJobName,String SearchLocation) throws Exception
	{
		LoggerLibrary.PostExecDetails("Launching URL : "+NaukriURL,micInfo,false);
		d.get(NaukriURL);
		NaukriDotCom.KillExcessWindows();
		WebPageActions ("Maximise");
		
		LoggerLibrary.PostExecDetails(NaukriURL+" launched successsfully",micInfo,true);
		
		NaukriDotCom.Click(LaterBtn);
		
		NaukriDotCom.Skills().click();
		NaukriDotCom.Skills().sendKeys(SearchJobName);
		NaukriDotCom.Skills().sendKeys(Keys.TAB);
		
		NaukriDotCom.Locations().click();
		NaukriDotCom.Locations().sendKeys(SearchLocation);
		NaukriDotCom.Locations().sendKeys(Keys.TAB);
		
		LoggerLibrary.PostExecDetails("Job Search For : "+SearchJobName+ " "+SearchLocation,micInfo,true);
		
		NaukriDotCom.SearchBtn().click();
		
		ArrayList<WebElement> AllResults = (ArrayList<WebElement>) d.findElements(ListOfJobs);
		
		int JobNo = 1;
		JobStorage.put(JobNo, new Object[] {"Job Title","Company Name","Experience","Salary","Location","Expectation","Skill Expected"});
		
		for (WebElement SingleResult : AllResults)
		{
			JobNo++;
			String strJobTitle = SingleResult.findElement(JobTitle).getText();
			String strCompanyName = SingleResult.findElement(CompanyName).getText();
			String strExperienceReq = SingleResult.findElement(ExperienceReq).getText();
			String strSalary = SingleResult.findElement(Salary).getText();
			String strLocation = SingleResult.findElement(Location).getText();
			String strExpectation = SingleResult.findElement(Expectation).getText();
			WebElement AllSkillSets = SingleResult.findElement(SkillDescription);
			
			String TotalSkills = "";
			ArrayList<WebElement> Skillset = (ArrayList<WebElement>) AllSkillSets.findElements(UnitSkill);
			for (WebElement Singleset:Skillset)
			{
				if (!Singleset.getText().toUpperCase().equals("IT SKILLS"))
				{
					if (TotalSkills=="")
						TotalSkills = Singleset.getText();
					else
						TotalSkills = TotalSkills + "," + Singleset.getText();
				}
			}
			
			JobStorage.put(JobNo, new Object[] {strJobTitle,strCompanyName,strExperienceReq,strSalary,strLocation,strExpectation,TotalSkills});
		}
		LoggerLibrary.PostExecDetails("Job Results For "+SearchJobName+ " "+SearchLocation,micInfo,true);
		d.quit();
	}
}
