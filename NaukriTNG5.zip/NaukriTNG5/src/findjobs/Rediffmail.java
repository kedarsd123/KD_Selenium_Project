package findjobs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Rediffmail extends Driver
{
	//Object Properties
	public static WebElement Element = null;
	static By RediffmailLink = By.xpath("//a[@title='Lightning fast free email']");
	static By LoginId = By.id("login1");
	static By Password = By.id("password");
	static By SignIn = By.name("proceed");
	static By WriteMail = By.xpath("//li[@title='Compose a new mail']");
	static By MailTo = By.xpath("//input[@placeholder='Enter name or email']");
	static By Subject = By.xpath("//input[@class ='rd_inp_sub rd_subject_datacmp2']");
	static By AttachFile = By.className("attch_fil");
	static By Send = By.xpath("//a[@class='send_ng_compo rd_btn_cmp_send']");
	static By LogOut = By.xpath("//a[@class='rd_logout']");
		
	public static WebElement RediffmailLink()
	{
		Element = d.findElement(RediffmailLink);
		return Element;
	}
		
	public static WebElement LoginId()
	{
		Element = d.findElement(LoginId);
		return Element;		
	}
		
	public static WebElement Password()
	{
		Element = d.findElement(Password);
		return Element;
	}
		
	public static WebElement SignIn()
	{
		Element = d.findElement(SignIn);
		return Element;
	}
		
	public static WebElement WriteMail()
	{	
		Element = d.findElement(WriteMail);
		return Element;
	}
		
	public static WebElement MailTo()
	{	
		Element = d.findElement(MailTo);
		return Element;
	}
		
	public static WebElement Subject()
	{	
		Element = d.findElement(Subject);
		return Element;
	}
		
	public static WebElement Send()
	{	
		Element = d.findElement(Send);
		return Element;
	}
		
	public static WebElement LogOut()
	{	
		Element = d.findElement(LogOut);
		return Element;
	}
		
	public static WebElement AttachFile()
	{
		Element = d.findElement(AttachFile);
		return Element;
	}
		
	public static void SendMail(String strUserName,String strRecepient,String strSubject) throws Exception
	{
		LoggerLibrary.PostExecDetails("Launching URL : "+RediffURL,micInfo,false);
		d.get(RediffURL);
		WebPageActions ("Maximise");
		LoggerLibrary.PostExecDetails(RediffURL+" launched successsfully",micInfo,true);
		
		Rediffmail.Click(RediffmailLink);
		Rediffmail.Paste(LoginId, ConfigDct.get("RmailId"));
		Rediffmail.Paste(Password, ConfigDct.get("RmailIdPwd"));
		LoggerLibrary.PostExecDetails("Rediffmail Login",micInfo,true);
		
		Rediffmail.Click(SignIn);
		Rediffmail.Click(WriteMail);
		Rediffmail.Paste(MailTo, strRecepient);
		Rediffmail.Paste(Subject,strSubject);
		Rediffmail.Click(AttachFile);
			
		try 
		{
			Runtime.getRuntime().exec(AutoITexe);
			Thread.sleep(15000);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			LoggerLibrary.PostExecDetails(e.toString(),micFail,false);
			ExitTest();
		}
		
		LoggerLibrary.PostExecDetails("Rediffmail Before Sending Mail",micInfo,true);
		Rediffmail.Click(Send);
		
		LoggerLibrary.PostExecDetails("Rediffmail Sent Successfully to : "+strUserName,micInfo,true);
		
		Rediffmail.Click(LogOut);
		
		LoggerLibrary.PostExecDetails("Rediffmail Logged Out",micInfo,true);
		d.quit();
	}	
}
