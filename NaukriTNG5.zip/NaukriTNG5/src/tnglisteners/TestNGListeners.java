package tnglisteners;

import org.testng.ITestListener;
import org.testng.ITestResult;

import findjobs.GlobalFunctions;
import findjobs.GlobalVariables;
import findjobs.LoggerLibrary;

public class TestNGListeners implements ITestListener,GlobalVariables
{
	@Override  
	public void onTestStart(ITestResult result) 
	{  
		try {
			LoggerLibrary.PostExecDetails("Test Start : "+ result.getName(),micInfo,false);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}  
	  
	@Override
	public void onTestSuccess(ITestResult result) 
	{  
		try {
			LoggerLibrary.PostExecDetails("Test Success : "+ result.getName(),micPass,false);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}  
	  
	@Override  
	public void onTestFailure(ITestResult result) 
	{  
		try {
			LoggerLibrary.PostExecDetails("Test Failed : "+ result.getName(),micFail,false);
			GlobalFunctions.ExitTest();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}  
	  
	@Override  
	public void onTestSkipped(ITestResult result) 
	{  
		try {
			LoggerLibrary.PostExecDetails("Test Skipped : "+ result.getName(),micWarning,false);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}  
	
}
